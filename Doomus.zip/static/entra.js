$(document).ready(function () {
    $('#id_username').addClass(" form-control col-5")
    $('#id_password').addClass(" form-control col-5")
})