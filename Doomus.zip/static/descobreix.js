
function reproduirmusic (nombre){
    document.getElementById(nombre).play();
}

function pararmusic (nombre){
    document.getElementById(nombre).load();
}
